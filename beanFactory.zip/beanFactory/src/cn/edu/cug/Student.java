package cn.edu.cug;

public class Student {
    public Student(){
        System.out.println("Student!");
    }
}
