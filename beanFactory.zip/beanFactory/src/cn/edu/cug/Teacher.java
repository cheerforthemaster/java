package cn.edu.cug;

public class Teacher {
    public Teacher(){
        System.out.println("Teacher!");
    }
}
